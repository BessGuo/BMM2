#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



void half(int x,int y)
{
	if(x==y)
		cout<<x<<endl;
	else if(x>y)
	{
		x=x/2;
		half(x,y);
	}
	else
	{
		y=y/2;
		half(x,y);
	}
}
int main()
{
	int x,y;
	cin>>x>>y;
	half(x,y);
	return 0;
}
