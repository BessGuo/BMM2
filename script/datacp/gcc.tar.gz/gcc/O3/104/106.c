// #include<cstdio>  
// #include<cstring>  
// #include<algorithm>  
// #include<iostream>  
// #include<string>  
// #include<vector>  
// #include<stack>  
// #include<bitset>  
// #include<cstdlib>  
// #include<cmath>  
// #include<set>  
// #include<list>  
// #include<deque>  
// #include<map>  
// #include<queue> 

#include<assert.h>
#include<ctype.h>
#include<errno.h>
#include<fenv.h>
#include<float.h>
#include<inttypes.h>
#include<iso646.h>
#include<limits.h>
#include<locale.h>
#include<math.h>
#include<setjmp.h>
#include<signal.h>
#include<stdarg.h>
#include<stdbool.h>
#include<stddef.h>
#include<stdint.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<tgmath.h>
#include<time.h>
#include<uchar.h>
#include<wchar.h>
#include<wctype.h>

void main()
{
	int x,y,i,k;
	int a[12]={0},b[12]={0};
	
	scanf("%d%d",&x,&y);
	
	a[0]=x;
	b[0]=y;
	for(i=0;a[i]>=2;i++)
	{
		a[i+1]=a[i]/2;
	}
	for(k=0;b[k]>=2;k++)
	{
		b[k+1]=b[k]/2;
	}
	if(x!=y)
	{
		for(;;i--,k--)
	    {
			if(a[i]!=b[k])
		    {
			    break;
		    }
	    }
		printf("%d\n",a[i+1]);
	}
	else
	{
		printf("%d\n",x);
	}

}