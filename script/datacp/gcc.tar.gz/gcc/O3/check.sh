for ((i=1;i<104;i++))
do
    # allN=`ls ${i}/ |wc -l`
    # cppN=`ls ${i}/*.cpp |wc -l`
    # cN=`ls ${i}/*.c |wc -l`
    # ((t1=$allN-$cppN))
    # ((binary=$t1-$cN))
    # echo "program "${i}" binary amount: "${binary}

    cd ${i}
    rm *.c
    rm *.cpp
    cd ..
done