// #include<cstdio>  
// #include<cstring>  
// #include<algorithm>  
// #include<iostream>  
// #include<string>  
// #include<vector>  
// #include<stack>  
// #include<bitset>  
// #include<cstdlib>  
// #include<cmath>  
// #include<set>  
// #include<list>  
// #include<deque>  
// #include<map>  
// #include<queue> 

#include<assert.h>
#include<ctype.h>
#include<errno.h>
#include<fenv.h>
#include<float.h>
#include<inttypes.h>
#include<iso646.h>
#include<limits.h>
#include<locale.h>
#include<math.h>
#include<setjmp.h>
#include<signal.h>
#include<stdarg.h>
#include<stdbool.h>
#include<stddef.h>
#include<stdint.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<tgmath.h>
#include<time.h>
#include<uchar.h>
#include<wchar.h>
#include<wctype.h>


void main()
{
	int i,j,m,n;
	int x[12]={0},y[12]={0};
	scanf("%d %d",&x[0],&y[0]);
	if(x[0]==1||y[0]==0)
		printf("1\n");
	else{
	for(i=1;;i++)
	{
		x[i]=x[i-1]/2;
		if(x[i]==1)
		{
			m=i;
			break;
		}
	}
	for(j=1;;j++)
	{
		y[j]=y[j-1]/2;
		if(y[j]==1)
		{
			n=j;
			break;
		}
	}
	for(i=m,j=n;i>=0,j>=0;i--,j--)
	{
		if(x[i]==y[j])
			if(i==0||j==0||x[i-1]!=y[j-1])
				printf("%d\n",x[i]);
			else
				continue;
		else
			break;
	}
	}
}