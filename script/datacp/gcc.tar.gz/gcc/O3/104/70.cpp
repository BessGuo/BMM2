#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



void main()
{
  int x,y,cx,cy,t;
  scanf("%d%d",&x,&y);
  t=2;cx=1;
  while(x>=t)
  {
    t=t*2;
	cx++;
  }
  t=2;cy=1;
  while(y>=t)
  {
    t=t*2;
	cy++;
  }
  while(!(x==y))
  {
    if(cx>=cy)
	{
      x=x/2;
	  cx--;
	}
	else
	{
      y=y/2;
	  cy--;
	}
  }
  printf("%d\n",x);
}