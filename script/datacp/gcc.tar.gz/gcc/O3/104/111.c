// #include<cstdio>  
// #include<cstring>  
// #include<algorithm>  
// #include<iostream>  
// #include<string>  
// #include<vector>  
// #include<stack>  
// #include<bitset>  
// #include<cstdlib>  
// #include<cmath>  
// #include<set>  
// #include<list>  
// #include<deque>  
// #include<map>  
// #include<queue> 

#include<assert.h>
#include<ctype.h>
#include<errno.h>
#include<fenv.h>
#include<float.h>
#include<inttypes.h>
#include<iso646.h>
#include<limits.h>
#include<locale.h>
#include<math.h>
#include<setjmp.h>
#include<signal.h>
#include<stdarg.h>
#include<stdbool.h>
#include<stddef.h>
#include<stdint.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<tgmath.h>
#include<time.h>
#include<uchar.h>
#include<wchar.h>
#include<wctype.h>

void main()
{
	int x0,y0,i,j,k,l=10000;
	int x[10],y[10]={0};

	scanf("%d%d",&x0,&y0);
	x[0]=x0;y[0]=y0;
	for(i=0;i<9;i++)
	{
		x[i+1]=x[i]/2;
	}
	for(i=0;i<9;i++)
	{
		y[i+1]=y[i]/2;
	}
	 
	for(i=0;i<10;i++)
	{
		for(j=0;j<10;j++)
		{
			if(x[i]==y[j])
			{l=i;break;}
		}
	if(i==l)break;
	}
		printf("%d",x[i]);
}
     
