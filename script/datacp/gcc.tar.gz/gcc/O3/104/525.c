// #include<cstdio>  
// #include<cstring>  
// #include<algorithm>  
// #include<iostream>  
// #include<string>  
// #include<vector>  
// #include<stack>  
// #include<bitset>  
// #include<cstdlib>  
// #include<cmath>  
// #include<set>  
// #include<list>  
// #include<deque>  
// #include<map>  
// #include<queue> 

#include<assert.h>
#include<ctype.h>
#include<errno.h>
#include<fenv.h>
#include<float.h>
#include<inttypes.h>
#include<iso646.h>
#include<limits.h>
#include<locale.h>
#include<math.h>
#include<setjmp.h>
#include<signal.h>
#include<stdarg.h>
#include<stdbool.h>
#include<stddef.h>
#include<stdint.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<tgmath.h>
#include<time.h>
#include<uchar.h>
#include<wchar.h>
#include<wctype.h>

void main()
{
	int x[11],y[11],i,j,m;
	int *p1,*p2;
	scanf("%d%d",&x[0],&y[0]);
	p1=&x[0];
    p2=&y[0];
	if(*p1==*p2||*p1==1||*p2==1){
		printf("%d",*p1);
	}
	else{
    for(i=0;i<13;i++){
	*(p1+1)=*p1/2;
	p1++;
		if(*p1==1){
			break;
		}
	}
	for(j=0;j<13;j++){
	*(p2+1)=*p2/2;
	p2++;
		if(*p2==1){
			break;
		}
	}
	for(m=0;m<13;m++){
		if(*p2!=*p1)
		{
	printf("%d",*(p2+1));
	break;
		}
		p1=p1-1;
		p2=p2-1;
	}
	}
}