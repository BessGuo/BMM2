#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



int k;
void tree(int m, int n)
{
	if (m == n)
		k = m;  
	else if (m > n)
		tree(m / 2, n); 
	else if (m < n)
		tree(m, n / 2);  
}
int main()
{
	int x, y;
	cin >> x >> y;
	tree(x , y); 
	cout << k;
	return 0;
}
