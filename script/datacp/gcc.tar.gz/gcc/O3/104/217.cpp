#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



void main()
{
    int x,y;
	scanf("%d %d",&x,&y);
    while(x!=y)
	{
	if(x<y)
    y=y/2;
	else if(x>y)
	x=x/2;
	}
	printf("%d\n",x);
}
