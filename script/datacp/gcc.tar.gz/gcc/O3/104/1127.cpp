#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



int find(int,int);
int find(int x,int y)
{
	int a;
	if(x>y) a=find(x/2,y);
	else if(x<y) a=find(x,y/2);
	else a=x;
	return a;
}
int main()
{
	int x,y;
	scanf("%d%d",&x,&y);
	printf("%d",find(x,y));
	return 0;
}