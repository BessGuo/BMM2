#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



void main(){
	int x,y;
	int same(int m,int n);
	scanf("%d%d",&x,&y);
	printf("%d",same(x,y));
}

int same(int x,int y){
	while(x!=y){
		if(x>y) x=x/2;
		else y=y/2;
	}
	return x;
}