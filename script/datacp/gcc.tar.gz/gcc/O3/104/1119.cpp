#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



 
int common(int x, int y) 
{
	if(x > y) return common(x / 2, y); 
	if(x < y) return common(x, y / 2);
	return x; 
}

int main() 
{
	int m = 0, n = 0;
	cin >> m >> n;
	cout << common(m, n) << endl; 
	return 0;
}