#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



void main()
{
  int i,m,n,temp;
  scanf("%d%d",&m,&n);
  if(m<n)
  {
    temp=m;
	m=n;
	n=temp;
  }
  if(m==n)  printf("%d\n",m);
  else
  {
  for(;;)
  {
    if(m/2==n)  
	{
		printf("%d\n",n);
		break;
	}
	else 
	{
	  if(m/2>n)  m/=2;
	  else
	  {
	    temp=n;
		n=m/2;
		m=temp;
	  }
	}
  }
  }
}