#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



void check(int x,int y)
{
	if(x==y)
		printf("%d",x);
	else
	{
		if(x>y&&x/2>=y/2)
			check(x/2,y);
		if(x<y&&x/2<=y/2)
			check(x,y/2);
	}
}
main()
{
	int x,y;
	scanf("%d %d",&x,&y);
	check(x,y);
}