#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



  


int gcd( int m, int n );

int main()
{
	int x, y;
	cin >> x >> y;
	cout << gcd( x, y );
	return 0;
}

int gcd( int m, int n )
{
	if( n>m )
		return gcd( m, n/2 );
	else if( m>n)
		return gcd( m/2, n );
	else
		return m;
}
