// #include<cstdio>  
// #include<cstring>  
// #include<algorithm>  
// #include<iostream>  
// #include<string>  
// #include<vector>  
// #include<stack>  
// #include<bitset>  
// #include<cstdlib>  
// #include<cmath>  
// #include<set>  
// #include<list>  
// #include<deque>  
// #include<map>  
// #include<queue> 

#include<assert.h>
#include<ctype.h>
#include<errno.h>
#include<fenv.h>
#include<float.h>
#include<inttypes.h>
#include<iso646.h>
#include<limits.h>
#include<locale.h>
#include<math.h>
#include<setjmp.h>
#include<signal.h>
#include<stdarg.h>
#include<stdbool.h>
#include<stddef.h>
#include<stdint.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<tgmath.h>
#include<time.h>
#include<uchar.h>
#include<wchar.h>
#include<wctype.h>


void main()
{
	int x,y;
	int a[2000]={0};
	int b[2000]={0};
	int i,j,k;
	int p;
	int l=0;
	a[0]=1;
	b[0]=1;

 

	scanf("%d%d",&x,&y);


	for(i=0;x!=0;i++)
	{
		a[i]=x;
		x=x/2;
	}
	for(j=0;y!=0;j++)
	{
		b[j]=y;
		y=y/2;
	}

	for(k=0;k<=i&&k<=j;k++)
	{
		if(a[i-k]==b[j-k])
			continue;
		else
		{
			printf("%d",a[i-k+1]);
			l=1;
			break;
		}
	}
	if(l==0)
		printf("%d",a[i-k+1]);
}