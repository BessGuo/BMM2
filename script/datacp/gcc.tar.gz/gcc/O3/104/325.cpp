#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



 
int jd(int x)
{if(x==1)
	return 1;
else{
		if(x%2)

		return (x-1)/2;
	else
		return x/2;
		}
} 
int main(){
	int x,y;
	cin>>x>>y;
	int lx=1,ly=1,s,t,p=0;
	int i,j;
	s=x;
	for(lx=1;;lx++)
	{if(s!=1)
		s=jd(s);
	else break;
	} 
	t=y; 
for(ly=1;;ly++){
	if(t!=1)
		t=jd(t);
	else break; 
}

s=x;
t=y;
	for(i=1;i<=lx;i++)
	{t=y;
		for(j=1;j<=ly;j++)
		{
			if(s==t)
			{p=1;
				cout<<t<<endl;
	break;	}
		else t=jd(t);}
		if(p)
			break;
	s=jd(s);
	} 



	return 0;
}
