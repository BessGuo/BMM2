#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



 



int main()
{
	int x,y,m;		 
	cin>>x>>y;		 
	while (y!=1)
	{
		m=x;		 
		while (m!=1)
		{
			if (m==y)		 
			{
				cout<<m;	 
				return 0;	 
			}
			m/=2;			 
		}
		y/=2;		 
	}
	cout<<1;		 
	return 0;		 
}