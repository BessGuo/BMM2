// #include<cstdio>  
// #include<cstring>  
// #include<algorithm>  
// #include<iostream>  
// #include<string>  
// #include<vector>  
// #include<stack>  
// #include<bitset>  
// #include<cstdlib>  
// #include<cmath>  
// #include<set>  
// #include<list>  
// #include<deque>  
// #include<map>  
// #include<queue> 

#include<assert.h>
#include<ctype.h>
#include<errno.h>
#include<fenv.h>
#include<float.h>
#include<inttypes.h>
#include<iso646.h>
#include<limits.h>
#include<locale.h>
#include<math.h>
#include<setjmp.h>
#include<signal.h>
#include<stdarg.h>
#include<stdbool.h>
#include<stddef.h>
#include<stdint.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<tgmath.h>
#include<time.h>
#include<uchar.h>
#include<wchar.h>
#include<wctype.h>

int tree(int x,int *a)
{
	static int i=1;

	if(x!=1)
	{
		x=x/2;
		*a=x;
		a++;
		tree(x,a);
		i++;
	}
	else
		*a=1;
	return i;
}


int por(int *e,int *r)
{
	static int q;
	if(*e!=*r)
	{printf("%d\n",q);}
	else
	{
		q=*e;
		e--;
		r--;
 
		por(e,r);
	}
	return q;
}

void main()
{
	int x,y,a[12],b[12],a1,b1;
	int *a2;
	int *b2;
	int *a3;
	int *b3;
	scanf("%d%d",&x,&y);
	a[0]=x;
	b[0]=y;
	a2=&a[1];
	b2=&b[1];
	a1=tree(x,a2)+1;
	b1=tree(y,b2)-a1+3;
 
	a3=&a[a1-1];
	b3=&b[b1-1];
	por(a3,b3);
 

}
