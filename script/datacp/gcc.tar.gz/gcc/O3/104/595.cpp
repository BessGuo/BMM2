#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



int com(int x, int y)
{
	int t;
	if(x==y) t=x;
	else 
		t=(x>y)?com(x/2,y):com(x,y/2);
	return t;
}
void main ()
{
	int x,y;
	scanf("%d %d",&x,&y);
	printf("%d\n",com(x,y));
}

	