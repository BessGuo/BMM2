// #include<cstdio>  
// #include<cstring>  
// #include<algorithm>  
// #include<iostream>  
// #include<string>  
// #include<vector>  
// #include<stack>  
// #include<bitset>  
// #include<cstdlib>  
// #include<cmath>  
// #include<set>  
// #include<list>  
// #include<deque>  
// #include<map>  
// #include<queue> 

#include<assert.h>
#include<ctype.h>
#include<errno.h>
#include<fenv.h>
#include<float.h>
#include<inttypes.h>
#include<iso646.h>
#include<limits.h>
#include<locale.h>
#include<math.h>
#include<setjmp.h>
#include<signal.h>
#include<stdarg.h>
#include<stdbool.h>
#include<stddef.h>
#include<stdint.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<tgmath.h>
#include<time.h>
#include<uchar.h>
#include<wchar.h>
#include<wctype.h>

void main()
{
  int x,y,cx,cy,t;
  scanf("%d%d",&x,&y);
  t=2;cx=1;
  while(x>=t)
  {
    t=t*2;
	cx++;
  }
  t=2;cy=1;
  while(y>=t)
  {
    t=t*2;
	cy++;
  }
  while(!(x==y))
  {
    if(cx>=cy)
	{
      x=x/2;
	  cx--;
	}
	else
	{
      y=y/2;
	  cy--;
	}
  }
  printf("%d\n",x);
}