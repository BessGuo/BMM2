#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



int main()
{
	int m,n;
	scanf("%d%d",&m,&n);
	while(m!=n)
	{
		if(m>n)
			m=m/2;
		else n=n/2;
	}
	printf("%d",m);
	return 0;
}