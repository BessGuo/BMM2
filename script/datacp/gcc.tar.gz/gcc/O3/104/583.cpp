#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



int main()
{
  int p,q;
  void y(int n,int m);
  scanf("%d%d",&q,&p);
  y(p,q);
  return 0;
}
void y(int n,int m)
{
  if(n==m)
  printf("%d",n);  
  else if(m>n)
  {
    if(m>=(2*n))
      y(m/2,n);
     else if(m<(2*n))
      y(m/2,n/2);
   } 
   else
      y(m,n);
 }
 