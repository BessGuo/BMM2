#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



 
int main()
{
	int x,y,i=1,min,max;
	cin>>x>>y;
	min=x;max=y;
	if(y<x)
		{min=y;max=x;}
	for(min=min;min>0;min=min/2)
		if(i)
		for(max=max;max>=min;max=max/2)
			if(max==min)
				{cout<<max;i=0;}}

