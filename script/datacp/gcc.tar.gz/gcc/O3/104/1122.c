// #include<cstdio>  
// #include<cstring>  
// #include<algorithm>  
// #include<iostream>  
// #include<string>  
// #include<vector>  
// #include<stack>  
// #include<bitset>  
// #include<cstdlib>  
// #include<cmath>  
// #include<set>  
// #include<list>  
// #include<deque>  
// #include<map>  
// #include<queue> 

#include<assert.h>
#include<ctype.h>
#include<errno.h>
#include<fenv.h>
#include<float.h>
#include<inttypes.h>
#include<iso646.h>
#include<limits.h>
#include<locale.h>
#include<math.h>
#include<setjmp.h>
#include<signal.h>
#include<stdarg.h>
#include<stdbool.h>
#include<stddef.h>
#include<stdint.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<tgmath.h>
#include<time.h>
#include<uchar.h>
#include<wchar.h>
#include<wctype.h>

void main(){
	int x,y;
	scanf("%d%d",&x,&y);
	int i,m,n;
	for(i=0;i<10;i++)
	{
		if(pow(2.0,i)<=x&&x<=pow(2.0,i+1)-1)
		{
			m=i;
			i=11;
		}
	}
	for(i=0;i<10;i++)
	{
		if(pow(2.0,i)<=y&&y<=pow(2.0,i+1)-1)
		{
			n=i;
			i=11;
		}
	}
	if(m>n)
	{
		for(i=1;i<=m-n;i++)
		{
			if(x/2*2==x) x=x/2;
			else x=(x-1)/2;
		}
	}
	if(n>m)
	{
		for(i=1;i<=n-m;i++)
		{
			if(y/2*2==y) y=y/2;
			else y=(y-1)/2;
		}
	}
	int f(int x,int y);
	printf("%d",f(x,y));
}

int f(int x,int y)
{
	int z;
	if(x==y) {z=x;return z;}
	else if(x/2*2==x&&y/2*2==y)
	{
		x=x/2;
		y=y/2;
		z=f(x,y);
	}
	else if(x/2*2!=x&&y/2*2!=y)
	{
		x=(x-1)/2;
		y=(y-1)/2;
		z=f(x,y);
	}
	else if(x/2*2!=x&&y/2*2==y)
	{
		x=(x-1)/2;
		y=y/2;
		z=f(x,y);
	}
	else if(x/2*2==x&&y/2*2!=y)
	{
		x=x/2;
		y=(y-1)/2;
		z=f(x,y);
	}
}