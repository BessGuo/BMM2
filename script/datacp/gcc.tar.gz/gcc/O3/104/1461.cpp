#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



int tree(int i,int j)
{
    if(i==j) return i;
    if(i>j)
    {
        return tree(i/2,j);   
    }
    if(i<j)
    {
        return tree(j,i);   
    }
    
}
int main()
{
    int i,j;
    cin>>i>>j;
    cout<<tree(i,j);
    return 0;
}
