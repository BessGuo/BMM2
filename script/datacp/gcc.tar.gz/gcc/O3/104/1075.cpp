#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



int work( int m,int n )
{    while ( m != n )   
       { if( m > n ) m /= 2;
        if( m < n  ) n /= 2;
        }
        printf("%d",m);
     
} 
int main()
{   int a , b,m;
    scanf("%d %d",&a,&b);
    work(a,b);

}
