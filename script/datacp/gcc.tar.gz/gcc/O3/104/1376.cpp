#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



int i,n,k;

void work(int p,int u)
{
	if (u==1) {cout<<p;exit (0);}
	if (p%(n-1)==0)
  if((n*p/(n-1)+k)%n==k)
	 work(n*p/(n-1)+k,u-1);
}
int main()
{
	cin>>n>>k;
	while (n!=k)
					if (n>k) n=n>>1; else k=k>>1;
  cout<<n;
	return 0;
}
