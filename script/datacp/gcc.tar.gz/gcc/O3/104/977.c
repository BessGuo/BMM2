// #include<cstdio>  
// #include<cstring>  
// #include<algorithm>  
// #include<iostream>  
// #include<string>  
// #include<vector>  
// #include<stack>  
// #include<bitset>  
// #include<cstdlib>  
// #include<cmath>  
// #include<set>  
// #include<list>  
// #include<deque>  
// #include<map>  
// #include<queue> 

#include<assert.h>
#include<ctype.h>
#include<errno.h>
#include<fenv.h>
#include<float.h>
#include<inttypes.h>
#include<iso646.h>
#include<limits.h>
#include<locale.h>
#include<math.h>
#include<setjmp.h>
#include<signal.h>
#include<stdarg.h>
#include<stdbool.h>
#include<stddef.h>
#include<stdint.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<tgmath.h>
#include<time.h>
#include<uchar.h>
#include<wchar.h>
#include<wctype.h>

int pre(int num)
{
	if(num==1)
		return 0;
	else
	{
		if(num%2)
			return (num-1)/2;
		else
			return num/2;
	}
}

void main()
{
	int n,m,x[100]={0},y[100]={0},i,j,k,d;
	scanf("%d%d",&n,&m);
	x[0]=n;
	y[0]=m;
	for(i=1;;i++)
	{
		x[i]=pre(x[i-1]);
		if(x[i]==0)
			break;
	}
	for(j=1;;j++)
	{
		y[j]=pre(y[j-1]);
		if(y[j]==0)
			break;
	}
	for(k=0;k<i;k++)
		for(d=0;d<j;d++)
			if(x[k]==y[d])
			{
				printf("%d",x[k]);
				goto L;
			}

L:
	printf("\n");
}


	
