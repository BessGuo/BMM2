#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;




void fuck(int x,int y){
	int temp;
	if(x==y)
		cout<<x;
	else{
		if(y<x) {temp=x;x=y;y=temp;}
	fuck(x,y/2);
	}
}

int main(){
	int x,y;
	cin>>x>>y;
	fuck(x,y);
	return 0;
}