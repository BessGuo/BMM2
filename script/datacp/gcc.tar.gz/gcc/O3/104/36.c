// #include<cstdio>  
// #include<cstring>  
// #include<algorithm>  
// #include<iostream>  
// #include<string>  
// #include<vector>  
// #include<stack>  
// #include<bitset>  
// #include<cstdlib>  
// #include<cmath>  
// #include<set>  
// #include<list>  
// #include<deque>  
// #include<map>  
// #include<queue> 

#include<assert.h>
#include<ctype.h>
#include<errno.h>
#include<fenv.h>
#include<float.h>
#include<inttypes.h>
#include<iso646.h>
#include<limits.h>
#include<locale.h>
#include<math.h>
#include<setjmp.h>
#include<signal.h>
#include<stdarg.h>
#include<stdbool.h>
#include<stddef.h>
#include<stdint.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<tgmath.h>
#include<time.h>
#include<uchar.h>
#include<wchar.h>
#include<wctype.h>

void main()
{
 int a,b,i=2,j=2,m[11]={0},n[11]={0};
 scanf("%d %d",&a,&b);
 m[1]=a;n[1]=b;
 m[0]=-1;n[0]=-2;
 while(a!=1) {m[i]=a/2;a=a/2;i++;}
 while(b!=1) {n[j]=b/2;b=b/2;j++;}
 i--;j--;
 while(m[i]==n[j]) {i--;j--;}
 printf("%d",m[i+1]);
}
 