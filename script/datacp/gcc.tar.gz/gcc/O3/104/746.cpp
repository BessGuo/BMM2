#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



 

int route(int x,int y){                 
	if(x==y) return x;
	if(x>y) return route(x/2,y);
	if(x<y) return route(x,y/2);
	else return route(x/2,y/2);
}


int main()
{
	int x,y;
	cin>>x>>y;
	cout<<route(x,y)<<endl;
	return 0;
}
