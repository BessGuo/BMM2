#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



 
 
 
 
 
 
 


int main()
{
    int x,y,sx,sy,nx[11],ny[11];
    cin>>x>>y;
    nx[10]=x;
    ny[10]=y;
    
    for(int i=10;i>0;i--)
        nx[i-1]=nx[i]/2;
    for(int i=10;i>0;i--)
        ny[i-1]=ny[i]/2;

    for(sx=0;sx<11;sx++)
        if(nx[sx]!=0)
        {
            sx--;
            break;
        }
    for(sy=0;sy<11;sy++)
        if(ny[sy]!=0)
        {
            sy--;
            break;
        }

    for(int i=0;i<11;i++)
    {
        if(nx[sx]!=ny[sy])
            break;
        sx++;
        sy++;
    }
    
    cout<<nx[sx-1]<<endl;
    
    return 0;
}
