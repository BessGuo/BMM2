#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



int main(){
  int i,j;
  for (cin>>i>>j;i!=j;){
    while (i>j) i/=2;
    while (j>i) j/=2;
  }
  cout<<j<<endl;
}