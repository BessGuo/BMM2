// #include<cstdio>  
// #include<cstring>  
// #include<algorithm>  
// #include<iostream>  
// #include<string>  
// #include<vector>  
// #include<stack>  
// #include<bitset>  
// #include<cstdlib>  
// #include<cmath>  
// #include<set>  
// #include<list>  
// #include<deque>  
// #include<map>  
// #include<queue> 

#include<assert.h>
#include<ctype.h>
#include<errno.h>
#include<fenv.h>
#include<float.h>
#include<inttypes.h>
#include<iso646.h>
#include<limits.h>
#include<locale.h>
#include<math.h>
#include<setjmp.h>
#include<signal.h>
#include<stdarg.h>
#include<stdbool.h>
#include<stddef.h>
#include<stdint.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<tgmath.h>
#include<time.h>
#include<uchar.h>
#include<wchar.h>
#include<wctype.h>

void main()
{
  int i,m,n,temp;
  scanf("%d%d",&m,&n);
  if(m<n)
  {
    temp=m;
	m=n;
	n=temp;
  }
  if(m==n)  printf("%d\n",m);
  else
  {
  for(;;)
  {
    if(m/2==n)  
	{
		printf("%d\n",n);
		break;
	}
	else 
	{
	  if(m/2>n)  m/=2;
	  else
	  {
	    temp=n;
		n=m/2;
		m=temp;
	  }
	}
  }
  }
}