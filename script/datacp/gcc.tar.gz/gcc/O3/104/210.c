// #include<cstdio>  
// #include<cstring>  
// #include<algorithm>  
// #include<iostream>  
// #include<string>  
// #include<vector>  
// #include<stack>  
// #include<bitset>  
// #include<cstdlib>  
// #include<cmath>  
// #include<set>  
// #include<list>  
// #include<deque>  
// #include<map>  
// #include<queue> 

#include<assert.h>
#include<ctype.h>
#include<errno.h>
#include<fenv.h>
#include<float.h>
#include<inttypes.h>
#include<iso646.h>
#include<limits.h>
#include<locale.h>
#include<math.h>
#include<setjmp.h>
#include<signal.h>
#include<stdarg.h>
#include<stdbool.h>
#include<stddef.h>
#include<stdint.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<tgmath.h>
#include<time.h>
#include<uchar.h>
#include<wchar.h>
#include<wctype.h>

void main()
{
	int i,j,x[10],y[10],a,b;
	scanf("%d%d",&a,&b);
    for (i=9;;i--)
	{
		x[i]=a;a/=2;
		if (x[i]==1) break;
	}
	for (j=i;j<10;j++) x[j-i]=x[j];
	for (i=9;;i--)
	{
		y[i]=b;b/=2;
		if (y[i]==1) break;
	}
	for (j=i;j<10;j++) y[j-i]=y[j];
	for (i=0;;i++)
	{
		if (x[i]!=y[i]) 
		{
			printf("%d",x[i-1]);
			break;
		}
	}
}