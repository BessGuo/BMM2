#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



 


int main(){
	int x,y;
	int i=0,j=0;
	cin>>x>>y;
	while(1){
		if(pow(2,i)>x)
			break;
		i++;
	}
	while(1){
		if(pow(2,j)>y)
			break;
		j++;
	}
	while(i>j){
		x=x/2;
		i--;
	}
	while(i<j){
		y=y/2;
		j--;
	}
	while(1){
		if(x==y)break;
		else{
			x=x/2;
			y=y/2;
		}
	}
	cout<<x;
	return 0;
}
