#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



int turn(int a,int b)
{
	int i,k;
	if(a==b)
		k=a;
	if(a>b)
	{
		k=turn(a/2,b);
	}
	if(a<b)
	{
		k=turn(a,b/2);
	}
	return k;
}
void main()
{
	int a,b;
		scanf("%d%d",&a,&b);
		printf("%d",turn(a,b));
}