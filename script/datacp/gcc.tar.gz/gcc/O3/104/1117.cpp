#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



int main()
{
	void Hanshu(int a,int b);
	int a,b,k;
	scanf("%d %d",&a,&b);
	Hanshu(a,b);
	return 0;
}

void Hanshu(int a,int b)
{
	if(a==b) printf("%d",a);
	else if(a>b)
	{
		a=a/2;Hanshu(a,b);
	}
	else
	{
		b=b/2;Hanshu(a,b);
	}
}