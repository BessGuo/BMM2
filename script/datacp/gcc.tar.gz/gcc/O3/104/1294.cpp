#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;





int main(int argc, char* argv[])
{
	int a,b;
	int temp;
	scanf("%d %d",&a,&b);
	do
	{
		if(a>b)
		  a=a/2;
		if(a<b)
		  b=b/2;
	}while(a!=b);
	printf("%d",a);
	return 0;
}