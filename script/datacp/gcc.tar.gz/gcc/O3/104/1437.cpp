#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



int main()
{
	int common(int,int);
	int x=0,y=0;
	cin>>x>>y;
	cout<<common(x,y)<<endl;
	return 0;
}
int common(int x,int y)
{
	if(x==y)
		return x;
	if(x>y)
		return common(x/2,y);
	else
		return common(x,y/2);
}
