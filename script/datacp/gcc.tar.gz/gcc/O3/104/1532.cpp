#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;




int main()
{
	int m,n,s = 0;
	cin>>m>>n;
	int a[100];
	
	a[0]=m;
	for(int i=0;i<=98;i++)
	{
		a[i+1]=a[i]/2;
		if(a[i+1]==1)
		{
			s=i+1;
			break;
		}
	}
	for(int h=0;h<=99;h++)
	{
		for(int i=0;i<=s;i++)
		{
			if(a[i]==n)
			{
				cout<<n;
				return 0;
			}
		}
				n=n/2;
	}
}