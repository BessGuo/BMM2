#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



int finder(int a,int b)
{
	int c;
	for(;a;a=a/2)
		for(c=b;c>=a;c=c/2)
			if(a==c)
			{
				printf("%d",c);
				return 0;
			}
}

int main()   
{   
	int a,b,c,d;
	scanf("%d%d",&a,&b);
	finder(a,b);  
	return 0;
}   