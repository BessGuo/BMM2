// #include<cstdio>  
// #include<cstring>  
// #include<algorithm>  
// #include<iostream>  
// #include<string>  
// #include<vector>  
// #include<stack>  
// #include<bitset>  
// #include<cstdlib>  
// #include<cmath>  
// #include<set>  
// #include<list>  
// #include<deque>  
// #include<map>  
// #include<queue> 

#include<assert.h>
#include<ctype.h>
#include<errno.h>
#include<fenv.h>
#include<float.h>
#include<inttypes.h>
#include<iso646.h>
#include<limits.h>
#include<locale.h>
#include<math.h>
#include<setjmp.h>
#include<signal.h>
#include<stdarg.h>
#include<stdbool.h>
#include<stddef.h>
#include<stdint.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<tgmath.h>
#include<time.h>
#include<uchar.h>
#include<wchar.h>
#include<wctype.h>

void main() 
{ 
	int x,y,i,m,n; 
	int a[15]={0},b[15]={0}; 
	
	scanf("%d %d",&x,&y); 
	
	a[0]=x; 
	b[0]=y; 
	
	if(x==y) 
	{ 
		printf("%d\n",x); 
		return; 
	} 
	
	for(i=0;i<11;i++) 
	{ 
		if(a[i]==0) 
		{ 
			m=i-1; 
			break; 
		} 
		
		else 
			a[i+1]=a[i]/2; 
	} 
	
	for(i=0;i<11;i++) 
	{ 
		if(b[i]==0) 
		{ 
			n=i-1; 
			break; 
		} 
		
		else b[i+1]=b[i]/2; 
	} 
	
	for(;;m--,n--) 
	{ 
		if(a[m]!=b[n]) 
			break; 
	} 
	
	printf("%d\n",a[m+1]); 
}
