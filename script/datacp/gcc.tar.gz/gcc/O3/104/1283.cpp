#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



int main(){
int a,b;
scanf("%d%d",&a,&b);
while(a!=b)
{
if(a>b)a/=2;
else b/=2;
}
printf("%d",a);
}