// #include<cstdio>  
// #include<cstring>  
// #include<algorithm>  
// #include<iostream>  
// #include<string>  
// #include<vector>  
// #include<stack>  
// #include<bitset>  
// #include<cstdlib>  
// #include<cmath>  
// #include<set>  
// #include<list>  
// #include<deque>  
// #include<map>  
// #include<queue> 

#include<assert.h>
#include<ctype.h>
#include<errno.h>
#include<fenv.h>
#include<float.h>
#include<inttypes.h>
#include<iso646.h>
#include<limits.h>
#include<locale.h>
#include<math.h>
#include<setjmp.h>
#include<signal.h>
#include<stdarg.h>
#include<stdbool.h>
#include<stddef.h>
#include<stdint.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<tgmath.h>
#include<time.h>
#include<uchar.h>
#include<wchar.h>
#include<wctype.h>

int zheng(int x,int i)
{
    int j;
    if(i!=1) 
    {
        for(j=1;j<i;j++)
            x=x/2;
    }
    return(x);
}
void main()
{
    int zheng(int x,int i);
    int x,y,i,j,temp=0;
    scanf("%d%d",&x,&y);
    if(x==y)
        printf("%d",x);
    else
    {
        for(i=1;i<=10;i++)
        {
            if(temp!=0)
               break;
            for(j=1;j<=10;j++)
            {
                if(zheng(x,i)==zheng(y,j))
                {
                    temp=zheng(y,j);
                    break;
                 }
             }
         }
         printf("%d",temp);
     }   
}