#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



int main(){
int x,y,m;
scanf("%d %d",&x,&y);
m=y;
while(x>=1){
	while(y>=1){
	   if(y==x){
		   printf("%d",y); return 0;
	   }
	   y=y/2;
	    
	}
	x=x/2;
	y=m;
}
return 0;
}