#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



int main()
{
	int a,b,i,t;
	scanf("%d%d",&a,&b);
	if(a==b)printf("%d",a);
	else {
		if(a<b){
			t=a;
			a=b;
			b=t;
		}
		while(a/2!=b){
			a=a/2;
			if(a/2<b){
				t=a;
				a=b;
				b=t;
		}
		}
	printf("%d",b);
	}
}