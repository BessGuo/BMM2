// #include<cstdio>  
// #include<cstring>  
// #include<algorithm>  
// #include<iostream>  
// #include<string>  
// #include<vector>  
// #include<stack>  
// #include<bitset>  
// #include<cstdlib>  
// #include<cmath>  
// #include<set>  
// #include<list>  
// #include<deque>  
// #include<map>  
// #include<queue> 

#include<assert.h>
#include<ctype.h>
#include<errno.h>
#include<fenv.h>
#include<float.h>
#include<inttypes.h>
#include<iso646.h>
#include<limits.h>
#include<locale.h>
#include<math.h>
#include<setjmp.h>
#include<signal.h>
#include<stdarg.h>
#include<stdbool.h>
#include<stddef.h>
#include<stdint.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<tgmath.h>
#include<time.h>
#include<uchar.h>
#include<wchar.h>
#include<wctype.h>

void main()
{
	int x,y;
	int i=0,j=0,k;
	int a[1000],b[1000];
	scanf("%d%d",&x,&y);
	a[0]=x;
	b[0]=y;
	while(a[i]!=1)
	{
		i=i+1;
		a[i]=a[i-1]/2;
	}
	while(b[j]!=1)
	{
		j=j+1;
		b[j]=b[j-1]/2;
	}

	if(i<=j)
	{
		for(k=0;k<i+1;k++)
		{
			if(a[k]==b[j-i+k])
			{	printf("%d",a[k]);
			break;
			}
			
		}
	}
	else
	{
		for(k=0;k<j+1;k++)
		{
			if(a[i-j+k]==b[k])
			{		printf("%d",b[k]);
			break;
			}
		}
	}
}

