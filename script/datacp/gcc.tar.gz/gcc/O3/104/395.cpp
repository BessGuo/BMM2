#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



int main()
{
  int m,n,i,j,flag=1;
  cin>>m>>n;
  for(i=m;i>0&&flag;i/=2)
   for(j=n;j>0&&flag;j/=2)
    if(i==j)
     {cout<<i;flag=0;} 
  return 0;
}

