// #include<cstdio>  
// #include<cstring>  
// #include<algorithm>  
// #include<iostream>  
// #include<string>  
// #include<vector>  
// #include<stack>  
// #include<bitset>  
// #include<cstdlib>  
// #include<cmath>  
// #include<set>  
// #include<list>  
// #include<deque>  
// #include<map>  
// #include<queue> 

#include<assert.h>
#include<ctype.h>
#include<errno.h>
#include<fenv.h>
#include<float.h>
#include<inttypes.h>
#include<iso646.h>
#include<limits.h>
#include<locale.h>
#include<math.h>
#include<setjmp.h>
#include<signal.h>
#include<stdarg.h>
#include<stdbool.h>
#include<stddef.h>
#include<stdint.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<tgmath.h>
#include<time.h>
#include<uchar.h>
#include<wchar.h>
#include<wctype.h>

void main()
{
	int a[12]={0},b[12]={0};
	int x,i,j;
	x=0;
    scanf("%d %d",&a[0],&b[0]);
	for(i=0;i<11;i++)
	{
		a[i+1]=a[i]/2;
		b[i+1]=b[i]/2;
	}
	for(i=0;i<12;i++)
		for(j=0;j<12;j++)
		{
			if(a[i]==b[j])
			{
				printf("%d",a[i]);
				x=1;
				break;
			}
			if(x==1)break;
		}
}
