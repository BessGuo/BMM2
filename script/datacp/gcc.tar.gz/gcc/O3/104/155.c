// #include<cstdio>  
// #include<cstring>  
// #include<algorithm>  
// #include<iostream>  
// #include<string>  
// #include<vector>  
// #include<stack>  
// #include<bitset>  
// #include<cstdlib>  
// #include<cmath>  
// #include<set>  
// #include<list>  
// #include<deque>  
// #include<map>  
// #include<queue> 

#include<assert.h>
#include<ctype.h>
#include<errno.h>
#include<fenv.h>
#include<float.h>
#include<inttypes.h>
#include<iso646.h>
#include<limits.h>
#include<locale.h>
#include<math.h>
#include<setjmp.h>
#include<signal.h>
#include<stdarg.h>
#include<stdbool.h>
#include<stddef.h>
#include<stdint.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<tgmath.h>
#include<time.h>
#include<uchar.h>
#include<wchar.h>
#include<wctype.h>

void main()
{
	int x, y, a[10]={0}, b[10]={0}, i, j, t;
	int *px, *py;
	void tree(int x, int *p);

	scanf("%d%d", &x, &y);

	px = a;
	py = b;
	tree(x, px);
	tree(y, py);
	t = 0;
	for(i=0; i<10; i++)
	{
		for(j=0; j<10; j++)
		{
			if(a[i]==b[j])
			{
				printf("%d", a[i]);
				t = 1;
				break;
			}
		}
		if(t == 1)
		     break;
	}

}

void tree(int x, int *p)
{
	int i;
	for(i=0; ; i++, p++)
	{
		*p = x;
		if(x!=1)
		{
			if(x%2 == 1)
				x = (x-1)/2;
			else
				x = x/2;
		}
		else
			break;
	}
}