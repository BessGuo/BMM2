#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



int main(){
	int i,j,x,y,a[1010];
	scanf("%d%d",&x,&y);
	memset(a,0,sizeof(a));
	for(i=x;i>0;i/=2){
		a[i]=1;
	}
	for(i=y;i>0;i/=2){
		if(a[i]){
			printf("%d",i);
			break;
		}
	}
	return 0;
}