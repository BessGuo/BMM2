#include<cstdio>  
#include<cstring>  
#include<algorithm>  
#include<iostream>  
#include<string>  
#include<vector>  
#include<stack>  
#include<bitset>  
#include<cstdlib>  
#include<cmath>  
#include<set>  
#include<list>  
#include<deque>  
#include<map>  
#include<queue> 

using namespace std;



int erchashu(int a,int b)
{
	if(a==b) return(a);
	if(a>b) return(erchashu(a/2,b));
	if(a<b) return(erchashu(a,b/2));
}
void main()
{
	int a,b,c;
	scanf("%d%d",&a,&b);
	c=erchashu(a,b);
	printf("%d",c);
}