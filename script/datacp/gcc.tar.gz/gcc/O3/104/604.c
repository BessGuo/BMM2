// #include<cstdio>  
// #include<cstring>  
// #include<algorithm>  
// #include<iostream>  
// #include<string>  
// #include<vector>  
// #include<stack>  
// #include<bitset>  
// #include<cstdlib>  
// #include<cmath>  
// #include<set>  
// #include<list>  
// #include<deque>  
// #include<map>  
// #include<queue> 

#include<assert.h>
#include<ctype.h>
#include<errno.h>
#include<fenv.h>
#include<float.h>
#include<inttypes.h>
#include<iso646.h>
#include<limits.h>
#include<locale.h>
#include<math.h>
#include<setjmp.h>
#include<signal.h>
#include<stdarg.h>
#include<stdbool.h>
#include<stddef.h>
#include<stdint.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<tgmath.h>
#include<time.h>
#include<uchar.h>
#include<wchar.h>
#include<wctype.h>

void main()
{
	int n;
	int i,j;
	int a1,a2;
	scanf("%d",&n);
	int a[100];
	a[0]=n;


	for(i=0;;i++)
	{if (a[i]==1) break;
	 
	 
	a[i+1]=a[i]/2;
	}

	int m;
	scanf("%d",&m);
	int b[100];
	b[0]=m;


	for(j=0;;j++)
	{if (b[j]==1) break;
	 
	 
	b[j+1]=b[j]/2;
	}


	 
	 
	 

	int flag;
	flag=0;
	for(a1=0;a1<=i;a1++)
		if (flag==0)
		for(a2=0;a2<=j;a2++)
			if (flag==0)
			if(a[a1]==b[a2]) {printf("%d\n",a[a1]); flag=1;}
	
}