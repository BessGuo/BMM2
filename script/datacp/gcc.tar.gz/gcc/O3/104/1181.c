// #include<cstdio>  
// #include<cstring>  
// #include<algorithm>  
// #include<iostream>  
// #include<string>  
// #include<vector>  
// #include<stack>  
// #include<bitset>  
// #include<cstdlib>  
// #include<cmath>  
// #include<set>  
// #include<list>  
// #include<deque>  
// #include<map>  
// #include<queue> 

#include<assert.h>
#include<ctype.h>
#include<errno.h>
#include<fenv.h>
#include<float.h>
#include<inttypes.h>
#include<iso646.h>
#include<limits.h>
#include<locale.h>
#include<math.h>
#include<setjmp.h>
#include<signal.h>
#include<stdarg.h>
#include<stdbool.h>
#include<stddef.h>
#include<stdint.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<tgmath.h>
#include<time.h>
#include<uchar.h>
#include<wchar.h>
#include<wctype.h>

void main()
{
	int x,y,i,countx,county,c,p,q;
	int a[11]={0},b[11]={0};
	scanf("%d %d",&x,&y);
	countx=1;
	county=1;
	c=0;
	p=x;
	q=y;
	while (p!=1)
	{
		countx++;
		p=p/2;
	}
		while (q!=1)
	{
		county++;
		q=q/2;
	}
		for(i=countx;i>=1;i--)
		{
			a[i]=x;
			x=x/2;
		}
		for(i=county;i>=1;i--)
		{
			b[i]=y;
			y=y/2;
		}
		for (i=1;i<=10;i++)
		{
			if(a[i]==b[i]&&a[i]!=0&&b[i]!=0) c=a[i];
			else break;
		}
	printf("%d",c);
}
 